import sqlite3
conn= sqlite3.connect("Expenditure.db")

#Creating cursor
c=conn.cursor()

#Creating Expenditure Table
def var_push(date,reason,amount):
    c.execute("""CREATE TABLE IF NOT EXISTS expenditures(
            date TEXT,
            reason TEXT,
            amount REAL
        )""")

    c.executemany(
        """INSERT INTO expenditures (date, reason, amount) 
        VALUES(?,?,?)""", (date,where_s,amt) )

    conn.commit()

def var_get(date,amount,reason):
    c.execute("SELECT * FROM expenditures")

    data = c.fetchall()

    print(data) 
    #Creating Loan Table
    c.execute("""CREATE TABLE IF NOT EXISTS loans(
            date TEXT,
            amount REAL,
            reason TEXT
        )""")

    conn.commit()
conn.close()
# c.executemany(
    #     """INSERT INTO expenditures (date, reason, amount) 
    #     VALUES(?,?,?)""", ('datel','d.keys()','d.values()') )

    # c.execute("SELECT * FROM expenditures")

    # data = c.fetchall()

    # print(data)